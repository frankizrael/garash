<?php

define('DB_NAME', 'seekdev_bmw-ecommerce');

/** MySQL database username */
define('DB_USER', 'seekdev_bmw');

/** MySQL database password */
define('DB_PASSWORD', '70z{Wv;@0A;Z');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');
